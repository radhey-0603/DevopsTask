#!/bin/bash

# Function to check if a Vagrant box is already added
box_exists() {
    vagrant box list | grep -q "$1"
}

# Function to initialize and provision the Vagrant box
initialize_box() {
    if ! box_exists "$1"; then
        echo "Adding the Ubuntu box..."
        vagrant box add "$1" https://vagrantcloud.com/ubuntu/boxes/bionic64
    fi

    if [ ! -d "vagrant1" ]; then
        mkdir vagrant1
    fi

    cd vagrant1

    if [ ! -f "Vagrantfile" ]; then
        echo "Initializing a new Vagrant environment..."
        vagrant init "$1"
    fi

    echo "Booting up and provisioning the Vagrant box..."
    vagrant up
}

# Check if Vagrant is installed
if ! command -v vagrant &> /dev/null; then
    echo "Vagrant is not installed. Please install Vagrant before running this script."
    exit 1
fi

# Define the Vagrant box name and version
box_name="ubuntu/bionic64"

# Run the initialization function
initialize_box "$box_name"

echo "Your Vagrant box is up and running."

